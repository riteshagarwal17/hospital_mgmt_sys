package com.example.demo.entities;

public class Doctor {

    private Long id;
	private String name;
    private Long age;
    private String gender;
    private String Qualification;
    
}
