package com.example.demo.services;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;
import com.example.demo.entities.Appointment;
import com.example.demo.repositories.*;

@Service
public class AppointmentServices {

    @Autowired
    private AppointmentRepository appointmentRepository;

    public Appointment scheduleAppointment(int patientId, int doctorId, String appointmentTime) {
        Appointment appointment = new Appointment(patientId, doctorId, appointmentTime);
        return appointmentRepository.save(appointment);
    }

    public boolean cancelAppointment(long appointmentId) {
        Optional<Appointment> appointment = appointmentRepository.findById(appointmentId);
        if (appointment.isPresent()) {
            appointmentRepository.deleteById(appointmentId);
            return true;
        }
        return false;
    }
}