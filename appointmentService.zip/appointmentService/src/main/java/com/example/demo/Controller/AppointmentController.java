package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import com.example.demo.services.*;
import com.example.demo.entities.*;

@RestController
@RequestMapping("/appointments")
public class AppointmentController {

    @Autowired
    private AppointmentServices appointmentService;

    @Autowired
    private RestTemplate restTemplate;

    private static final String PATIENT_SERVICE_URL = "http://patient-service/patients/";
    private static final String DOCTOR_SERVICE_URL = "http://doctor-service/doctors/";

    @PostMapping("/schedule")
    public Appointment scheduleAppointment(@RequestParam int patientId, @RequestParam int doctorId, @RequestParam String appointmentTime) {

    	Patient patient = restTemplate.getForObject(PATIENT_SERVICE_URL + patientId, Patient.class);

        Doctor doctor = restTemplate.getForObject(DOCTOR_SERVICE_URL + doctorId, Doctor.class);

        if (patient != null && doctor != null) {
            // Schedule appointment
            return appointmentService.scheduleAppointment(patientId, doctorId, appointmentTime);
        } else {
            throw new RuntimeException("Invalid patient or doctor ID");
        }
    }

    @DeleteMapping("/cancel/{appointmentId}")
    public boolean cancelAppointment(@PathVariable int appointmentId) {
        return appointmentService.cancelAppointment(appointmentId);
    }
}