package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import com.example.demo.repositories.DepartmentRepository;
import org.springframework.stereotype.Service;
import java.util.*;
import com.example.demo.entities.*;

@Service
public class DepartmentService {


	@Autowired
	private DepartmentRepository departmentRepository;

	public List<Department> getAllDepartments() {
		return departmentRepository.findAll();
	}

	public Optional<Department> getDepartmentById(Long id) {
		return departmentRepository.findById(id);
	}

	public Department addDepartment(Department department) {
		return departmentRepository.save(department);
	}

	public Department updateDepartment(Long id, Department departmentDetails) {
		Department department = departmentRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Doctor not found for this id :: " + id));
		department.setDeptName(departmentDetails.getDeptName());
		department.setDeptDesc(departmentDetails.getDeptDesc());
//		department.setQualification(departmentDetails.getQualification());
		final Department updatedDepartment = departmentRepository.save(department);
		return updatedDepartment;
	}

	public void deleteDepartment(Long id) {
		Department department = departmentRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Doctor not found for this id :: " + id));
		departmentRepository.delete(department);
		
	}
	
}
