package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.example.demo.repositories.*;
import com.example.demo.entities.*;

@Service
public class PatientService {
	
	@Autowired
	private PatientRepository patientRepository;

	public List<Patient> getAllPatients() {
		return patientRepository.findAll();
	}

	public Optional<Patient> getPatientById(Long id) {
		return patientRepository.findById(id);
	}

	public Patient addPatient(Patient patient) {
		return patientRepository.save(patient);
	}

	public Patient updatePatient(Long id, Patient patientDetails) {
		Patient patient = patientRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Patient not found for this id :: " + id));
		patient.setName(patientDetails.getName());
		patient.setAge(patientDetails.getAge());
		patient.setAddress(patientDetails.getAddress());
		patient.setGender(patientDetails.getGender());
		final Patient updatedPatient = patientRepository.save(patient);
		return updatedPatient;
	}

	public void deletePatient(Long id) {
		Patient patient = patientRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Patient not found for this id :: " + id));
		patientRepository.delete(patient);
	}
}