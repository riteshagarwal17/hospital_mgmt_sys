package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.example.demo.repositories.*;
import com.example.demo.entities.*;

@Service
public class DoctorService {
	
	@Autowired
	private DoctorRepository doctorRepository;

	public List<Doctor> getAllDoctors() {
		return doctorRepository.findAll();
	}

	public Optional<Doctor> getDoctorById(Long id) {
		return doctorRepository.findById(id);
	}

	public Doctor addDoctor(Doctor doctor) {
		return doctorRepository.save(doctor);
	}

	public Doctor updateDoctor(Long id, Doctor doctorDetails) {
		Doctor doctor = doctorRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Doctor not found for this id :: " + id));
		doctor.setName(doctorDetails.getName());
		doctor.setAge(doctorDetails.getAge());
		doctor.setQualification(doctorDetails.getQualification());
		final Doctor updatedDoctor = doctorRepository.save(doctor);
		return updatedDoctor;
	}

	public void deleteDoctor(Long id) {
		Doctor doctor = doctorRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Doctor not found for this id :: " + id));
		doctorRepository.delete(doctor);
		
	}
}
