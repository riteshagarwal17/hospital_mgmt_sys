	package com.example.demo.entities;
	import lombok.Data;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	
@Data
@Entity
public class Doctor {	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
		private String name;
	    private Long age;
	    private String gender;
	    private String Qualification;
	    
	    public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public Long getAge() {
			return age;
		}

		public void setAge(Long age) {
			this.age = age;
		}

		public String getGender() {
			return gender;
		}

		public void setGender(String gender) {
			this.gender = gender;
		}

		public String getQualification() {
			return Qualification;
		}

		public void setQualification(String Qualification) {
			this.Qualification = Qualification;
		}

	    // Default constructor
	    public Doctor() {
	    }

	    // Parameterized constructor
	    public Doctor(Long id, String name, Long age, String gender, String Qualification) {
	        this.id = id;
	        this.name = name;
	        this.age = age;
	        this.gender = gender;
	        this.Qualification = Qualification;
	    }

	    // Getters and setters for all attributes
	    // No need to explicitly define them when using Lombok's @Data annotation

	    // Override toString() method for easy debugging
	    @Override
	    public String toString() {
	        return "Doctor{" +
	                "id=" + id +
	                ", name='" + name + '\'' +
	                ", age=" + age +
	                ", gender='" + gender + '\'' +
	                ", Qualification='" + Qualification + '\'' +
	                '}';
	    }
	}
